<h1 align="center">
  CMBF Rana MZ
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://www.facebook.com/RanaMZ.07">Rana MZ_</a>
</p>
<p align="center">
 <img src=cmbf/blob/main/img/IMG_20210328_191052.jpg" width="640" title="Menu" alt="Menu">
</p>
<img src=/cmbf/blob/main/img/IMG_20210328_191109.jpg" width="640" title="Menu" alt="Menu">
</p>

<a href=followers">
<img title="Followers" src="https://img.shields.io/github/followers/Yayan-XD?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Yayan-XD/termux-style/stargazers/">
  <a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Yayan-XD/cmbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Yayan-XD/cmbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Search" src="https://img.shields.io/github/search/Yayan-XD/Craker/cmbf.svg"/>
  </a>
  <a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Starts" src="https://img.shields.io/github/stars/Yayan-XD/cmbf.svg"/>
  </a>
<a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Yayan-XD/cmbf.svg"/>
  </a>

<a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Yayan-XD/cmbf.svg"/> <a href="https://github.com/Yayan-XD/cmbf">
    <img alt="Forks" src="https://img.shields.io/github/forks/Yayan-XD/cmbf.svg"/>
  </a>
</div>
<p align="center">

## Install script on Termux
```bash
$ apt update && apt upgrade
$ apt install python2
$ pip2 install mechanize
$ pip2 install requests bs4
$ apt install git
$ rm -rf cmb
$ git clone https://github.com/RanaMZ/mz.py.git
```
## Run script
```bash
$ cd cmbf
$ python2 cmbf.py
```
## Informasi For Updates Script
```
* Dump id from friends
* Dump id from friends public
* Dump id from total followers
* Dump id from link post
````
* Mutli type login :
 - [Cookis](https://youtu.be/1vDsjuFqrWQ)
 - [Token](https://youtu.be/O98qM-6L6E0)


#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&lo) [![](https://img.shields.io/badge/Twitter-blue?)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/RanaMZ.07)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)]() [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285603036683?text=Asalamualaikum+bang)

#### Donate :

<a href="https://saweria.co/YayanXD"><img src="https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_dana_blue.svg" alt="alt text" width="80" height="80"></a> &nbsp;&nbsp;

* Notice Me : Please Don't Change Name Author
Thanks For Using My Script
